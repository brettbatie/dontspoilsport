<!DOCTYPE html>
<html>
<head>
<title>Don't Spoil Sport</title>
<meta name="viewport" content="width=device-width" />
<link rel="stylesheet" type="text/css" href="/style.css">
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.0/themes/base/jquery-ui.css" />
<link rel="shortcut icon" href="/images/icon.png"/>
  <script src="http://code.jquery.com/jquery-1.8.3.js"></script>
  <script src="http://code.jquery.com/ui/1.10.0/jquery-ui.js"></script>
  <script src="/js/code.js"></script>
</head>

<body>

<header>
<h1><a href="/" style="text-decoration: none; color: white;">Don't Spoil Sport</a></h1>
</header>


<div class="wrapper">
<div class="main">
