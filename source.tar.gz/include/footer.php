</div><!-- .main -->

<footer>
<a href="/about.php">About Us</a>
<a href="https://github.com/infinityetc/dontspoilsport" style="float: right;">Source Code on GitHub</a>
</footer>


</div><!-- .wrapper -->

</body>

</html>
