<?php
require_once('include/header.php');
?>

<h2>About Us</h2>

<p>This project was built for Sports Hack Day in Seattle. We utilized APIs from ESPN and Sports Data.</p>

<div class="about">
<img alt="Don't Spoil Sport Team Photo" src="images/team.jpg" />
</div>

<p>We are Brett, Frank, Travis, and Dan.</p>

<?php
require_once('include/footer.php');
?>
