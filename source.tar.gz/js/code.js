/* Super Basic JS */

$(document).ready(function() {
	$('#week').hide();
	$('#change').click(function() {
		$('#week').toggle();
	});
});
